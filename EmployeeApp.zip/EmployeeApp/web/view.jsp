<%-- 
    Document   : view
    Created on : 6 Apr 2025, 5:33:27 pm
    Author     : ABHISHEK MISHRA
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="model.Employee" %>
<%
    List<Employee> list = (List<Employee>) request.getAttribute("list");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Employee List</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #74ebd5, #ACB6E5);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
            color: #333;
        }

        table {
            width: 80%;
            margin: auto;
            background: #ffffffcc;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 12px 20px;
            text-align: left;
        }

        th {
            background-color: #0077b6;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        a {
            color: #0077b6;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .add-btn {
            display: block;
            width: 150px;
            margin: 20px auto;
            padding: 10px;
            background-color: #00b4d8;
            color: white;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }

        .add-btn:hover {
            background-color: #0077b6;
        }


    </style>
</head>
<body>
    <h1 style="text-align:center;">Employee Management</h1>
    <a href="EmployeeServlet?action=add" class="add-btn">+ Add Employee</a>
    <table border="1">
        <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Department</th><th>Actions</th>
        </tr>
        <%
            for (Employee emp : list) {
        %>
        <tr>
            <td><%= emp.getId() %></td>
            <td><%= emp.getName() %></td>
            <td><%= emp.getEmail() %></td>
            <td><%= emp.getDepartment() %></td>
            <td>
                <a href="EmployeeServlet?action=edit&id=<%= emp.getId() %>">Edit</a> |
                <a href="EmployeeServlet?action=delete&id=<%= emp.getId() %>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <%
            }
        %>
    </table>
</body>
</html>
