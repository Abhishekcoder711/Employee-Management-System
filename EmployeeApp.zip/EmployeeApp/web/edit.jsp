<%-- 
    Document   : edit
    Created on : 6 Apr 2025, 5:33:14 pm
    Author     : ABHISHEK MISHRA
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="model.Employee" %>
<%
    Employee emp = (Employee) request.getAttribute("employee");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Employee</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #74ebd5, #ACB6E5);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
        }

        .form-container {
            width: 400px;
            margin: 50px auto;
            background: #ffffffdd;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        h2 {
            text-align: center;
            color: #0077b6;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input[type="text"], input[type="email"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            margin-top: 20px;
            width: 100%;
            background-color: #00b4d8;
            border: none;
            padding: 10px;
            color: white;
            font-weight: bold;
            border-radius: 6px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0077b6;
        }


    </style>
</head>
<body>
    <div class="form-container">
        <h2>Edit Employee</h2>
        <form action="EmployeeServlet" method="post">
            <input type="hidden" name="id" value="<%= emp.getId() %>" />

            <label>Name:</label>
            <input type="text" name="name" value="<%= emp.getName() %>" required />

            <label>Email:</label>
            <input type="email" name="email" value="<%= emp.getEmail() %>" required />

            <label>Department:</label>
            <input type="text" name="department" value="<%= emp.getDepartment() %>" required />

            <input type="submit" value="Update Employee" />
        </form>
    </div>
</body>
</html>
