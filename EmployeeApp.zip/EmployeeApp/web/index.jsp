<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Forward request to the EmployeeServlet
%>
<jsp:forward page="EmployeeServlet"/>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Redirecting...</title>
    <style>
        body {
            margin: 0;
            height: 100vh;
            background: linear-gradient(135deg, #74ebd5, #ACB6E5);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: sans-serif;
            color: white;
            font-size: 1.5rem;
        }

    </style>
</head>
<body>
    Redirecting to employee list...
    <jsp:forward page="EmployeeServlet"/>
</body>
</html>