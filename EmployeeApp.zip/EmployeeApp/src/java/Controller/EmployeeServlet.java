/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.sql.SQLException;
import model.Employee;
import model.EmployeeDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author ABHISHEK MISHRA
 */
@WebServlet(name = "EmployeeServlet", urlPatterns = {"/EmployeeServlet"})
public class EmployeeServlet extends HttpServlet {
    private EmployeeDAO dao;
    @Override
    public void init() {
        dao = new EmployeeDAO();
    }
    
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            switch (action == null ? "view" : action) {
                case "add" -> request.getRequestDispatcher("add.jsp").forward(request, response);
                case "edit" -> {
                    int id = Integer.parseInt(request.getParameter("id"));
                    Employee emp = dao.getEmployee(id);
                    request.setAttribute("employee", emp);
                    request.getRequestDispatcher("edit.jsp").forward(request, response);
                }
                case "delete" -> {
                    dao.deleteEmployee(Integer.parseInt(request.getParameter("id")));
                    response.sendRedirect("EmployeeServlet");
                }
                default -> {
                    request.setAttribute("list", dao.getAllEmployees());
                    request.getRequestDispatcher("view.jsp").forward(request, response);
                }
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String idStr = request.getParameter("id");
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String department = request.getParameter("department");

            if (idStr == null || idStr.isEmpty()) {
                dao.insertEmployee(new Employee(name, email, department));
            } else {
                dao.updateEmployee(new Employee(Integer.parseInt(idStr), name, email, department));
            }
            response.sendRedirect("EmployeeServlet");
            } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
    