/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class EmployeeDAO {
    private Connection getConnection() throws SQLException {
        Connection conn = null;
        try {
            Properties props = new Properties();
            InputStream input = getClass().getClassLoader().getResourceAsStream("db.properties");
            if (input == null) {
                System.out.println("⚠️ db.properties file not found in classpath!");
                return null;
            }
            props.load(input);

            String url = props.getProperty("jdbc.url");
            String user = props.getProperty("jdbc.username");
            String pass = props.getProperty("jdbc.password");
            String driver = props.getProperty("jdbc.driver");

        
            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, pass);

        } catch (IOException e) {
            System.out.println("⚠️ Failed to load db.properties: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("⚠️ JDBC Driver class not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("⚠️ Database connection error: " + e.getMessage());
            throw e; // rethrow for handling
        }
        return conn;
    }

    public void insertEmployee(Employee emp) throws SQLException {
        String sql = "INSERT INTO employees (name, email, department) VALUES (?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, emp.getName());
            stmt.setString(2, emp.getEmail());
            stmt.setString(3, emp.getDepartment());
            stmt.executeUpdate();
        }
    }


    public void updateEmployee(Employee emp) throws SQLException {
        String sql = "UPDATE employees SET name=?, email=?, department=? WHERE id=?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, emp.getName());
            stmt.setString(2, emp.getEmail());
            stmt.setString(3, emp.getDepartment());
            stmt.setInt(4, emp.getId());
            stmt.executeUpdate();
        }
    }


    public void deleteEmployee(int id) throws SQLException {
        String sql = "DELETE FROM employees WHERE id=?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    
    public Employee getEmployee(int id) throws SQLException {
        Employee emp = null;
        String sql = "SELECT * FROM employees WHERE id=?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                emp = new Employee(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("department")
                );
            }
        }
        return emp;
    }

    
    public List<Employee> getAllEmployees() throws SQLException {
        List<Employee> list = new ArrayList<>();
        String sql = "SELECT * FROM employees";
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Employee emp = new Employee(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("department")
                );
                list.add(emp);
            }
        }
        return list;
    }
}
